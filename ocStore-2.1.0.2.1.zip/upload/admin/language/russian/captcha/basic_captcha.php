<?php
$_['heading_title']    = 'Basic Captcha';

// Text
$_['text_captcha']     = 'Captcha';
$_['text_success']	   = 'Настройки Basic Captcha успешно обновлены!';
$_['text_edit']        = 'Редактирование Basic Captcha';

// Entry
$_['entry_status']     = 'Статус';

// Error
$_['error_permission'] = 'У Вас нет прав для управления этим модулем!';
