<?php
// Text
$_['text_footer'] 	= '<a target="_blank" href="http://myopencart.com">ocStore</a> &copy; 2009-' . date('Y') . ' Все права защищены.';
$_['text_version'] 	= 'Версия ocStore %s';