<?php
$_['text_complete_status']          = 'Выполненных заказов';
$_['text_processing_status']        = 'Заказов в обработке';
$_['text_other_status']          	= 'Другие статусы';