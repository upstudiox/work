<?php
// Heading
$_['heading_title'] = 'Статистика продаж';

// Text
$_['text_order']    = 'Заказов';
$_['text_customer'] = 'Покупателей';
$_['text_day']      = 'Сегодня';
$_['text_week']     = 'За неделю';
$_['text_month']    = 'За месяц';
$_['text_year']     = 'За этот год';