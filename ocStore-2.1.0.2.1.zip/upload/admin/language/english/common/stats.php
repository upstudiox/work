<?php
$_['text_complete_status']   = 'Orders Completed'; 
$_['text_processing_status'] = 'Orders Processing'; 
$_['text_other_status']      = 'Other Statuses'; 